package com.actuator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActuatorDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
