package com.thymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoThymeleafApp {
    public static void main(String[] args) {
        SpringApplication.run(DemoThymeleafApp.class, args);
    }
}