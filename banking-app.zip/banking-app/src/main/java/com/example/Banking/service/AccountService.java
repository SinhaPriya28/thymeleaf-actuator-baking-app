package com.example.Banking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Banking.entity.Account;
import com.example.Banking.entity.Customer;
import com.example.Banking.repository.AccountRepository;
import com.example.Banking.repository.CustomerRepository;

@Service
public class AccountService {
    @Autowired 
    private AccountRepository accountRepository;
    @Autowired 
    private CustomerRepository customerRepository;

    public Account createAccount(Long customerId, Account account) {
        Customer customer = customerRepository.findById(customerId).orElseThrow();
        account.setCustomer(customer);
        return accountRepository.save(account);
    }

    public List<Account> getAllAccounts() {
        return accountRepository.findAll();
    }

    public Optional<Account> getAccount(Long id) {
        return accountRepository.findById(id);
    }

    public void deleteAccount(Long id) {
        accountRepository.deleteById(id);
    }
}
